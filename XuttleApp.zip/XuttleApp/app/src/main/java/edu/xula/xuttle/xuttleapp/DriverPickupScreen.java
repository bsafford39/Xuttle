package edu.xula.xuttle.xuttleapp;

import android.app.Activity;
import android.os.Bundle;


/**
 * Created by Brittany on 10/1/2016.
 */

public class DriverPickupScreen extends Activity{

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.driver_pick_up_screen);

    }
}
